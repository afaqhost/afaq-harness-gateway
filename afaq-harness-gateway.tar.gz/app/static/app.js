const $ = (selector) => document.querySelector(selector);
const token = () => localStorage.getItem('afaq_token');
let language = 'ar';

const translations = {
  ar: {
    newChat: 'محادثة جديدة', chat: 'المحادثة', harnesses: 'الهارنسس', apiKeys: 'مفاتيح API', users: 'المستخدمون', docs: 'التوثيق', workspace: 'مساحة العمل', chatSubtitle: 'تحدث مع أي Harness من مكان واحد', online: 'البوابة متصلة', secureAccess: 'وصول آمن', loginTitle: 'تسجيل الدخول', loginDescription: 'أدخل بيانات حسابك للوصول إلى لوحة Afaq.', email: 'البريد الإلكتروني', password: 'كلمة المرور', login: 'دخول', welcomeTitle: 'مساحة تفكير واحدة،', welcomeDescription: 'اختر موديلًا من القائمة وابدأ محادثة جديدة.', model: 'الموديل', loading: 'جارٍ التحميل...', messagePlaceholder: 'اكتب رسالتك هنا...', enterHint: 'Enter للإرسال · Shift + Enter لسطر جديد', send: 'إرسال', harnessTitle: 'الأدوات المتصلة', refresh: 'تحديث الموديلات', keyTitle: 'مفاتيح الوصول', createKey: 'إنشاء مفتاح', userTitle: 'المستخدمون والصلاحيات', addUser: 'إضافة مستخدم', displayName: 'الاسم', docsTitle: 'ابدأ خلال دقائق', docsIntro: 'استخدم Afaq Gateway كواجهة متوافقة مع OpenAI للوصول إلى أدوات الذكاء الاصطناعي من أي تطبيق.', docsAuthTitle: 'المصادقة', docsAuthText: 'أنشئ API Key وأرسله في ترويسة Bearer مع كل طلب شات.', docsModelsTitle: 'الموديلات', docsModelsText: 'استخدم GET /v1/models لمعرفة الموديلات المتاحة.', docsResponseTitle: 'الاستجابة', docsResponseText: 'النص النهائي موجود في choices[0].message.content.', docsModelsHeading: 'جلب الموديلات', docsModelsBody: 'يعيد هذا المسار الموديلات المكتشفة من الهارنسس المثبتة.', docsChatHeading: 'إرسال رسالة', docsChatBody: 'استبدل API Key والموديل بقيم موجودة في حسابك.', docsStreamHeading: 'البث المباشر', docsStreamText: 'فعّل stream للحصول على أجزاء SSE تدريجيًا، وتنتهي الاستجابة الناجحة بـ data: [DONE].', docsErrorsTitle: 'أخطاء شائعة', docsErrorsText: '401 يعني أن المفتاح غير صالح أو معطل، و400 يعني أن اسم الهارنس غير معروف، و502 يعني أن أداة CLI فشلت.', keyName: 'اسم المفتاح', create: 'إنشاء', keyWarning: 'احفظ هذا المفتاح الآن، لن يظهر كاملًا مرة أخرى.', copy: 'نسخ', copied: 'تم نسخ المفتاح', active: 'فعال', disabled: 'معطل', enable: 'تفعيل', disable: 'تعطيل', delete: 'حذف', noKeys: 'لا توجد مفاتيح حتى الآن', deleteConfirm: 'هل تريد حذف هذا المفتاح نهائيًا؟', keyError: 'تعذر إنشاء المفتاح', toggleError: 'تعذر تغيير حالة المفتاح', deleteError: 'تعذر حذف المفتاح', refreshError: 'تعذر تحديث الموديلات'
  },
  en: {
    newChat: 'New chat', chat: 'Chat', harnesses: 'Harnesses', apiKeys: 'API keys', users: 'Users', docs: 'Docs', workspace: 'Workspace', chatSubtitle: 'Talk to any harness from one place', online: 'Gateway online', secureAccess: 'Secure access', loginTitle: 'Sign in', loginDescription: 'Enter your account details to access Afaq.', email: 'Email address', password: 'Password', login: 'Sign in', welcomeTitle: 'One thinking space,', welcomeDescription: 'Choose a model and start a new conversation.', model: 'Model', loading: 'Loading...', messagePlaceholder: 'Write your message...', enterHint: 'Enter to send · Shift + Enter for a new line', send: 'Send', harnessTitle: 'Connected tools', refresh: 'Refresh models', keyTitle: 'Access keys', createKey: 'Create key', userTitle: 'Users and permissions', addUser: 'Add user', displayName: 'Name', docsTitle: 'Get started in minutes', docsIntro: 'Use Afaq Gateway as an OpenAI-compatible interface for AI tools from any application.', docsAuthTitle: 'Authentication', docsAuthText: 'Create an API key and send it as a Bearer header with every chat request.', docsModelsTitle: 'Models', docsModelsText: 'Use GET /v1/models to see the available models.', docsResponseTitle: 'Response', docsResponseText: 'The final text is at choices[0].message.content.', docsModelsHeading: 'List models', docsModelsBody: 'This route returns models discovered from installed harnesses.', docsChatHeading: 'Send a message', docsChatBody: 'Replace the API key and model with values from your account.', docsStreamHeading: 'Streaming', docsStreamText: 'Set stream to true for incremental SSE chunks. Successful streams end with data: [DONE].', docsErrorsTitle: 'Common errors', docsErrorsText: '401 means the key is invalid or disabled, 400 means the harness is unknown, and 502 means the CLI failed.', keyName: 'Key name', create: 'Create', keyWarning: 'Save this key now. It will not be shown in full again.', copy: 'Copy', copied: 'Key copied', active: 'Active', disabled: 'Disabled', enable: 'Enable', disable: 'Disable', delete: 'Delete', noKeys: 'No keys yet', deleteConfirm: 'Delete this key permanently?', keyError: 'Could not create the key', toggleError: 'Could not change key status', deleteError: 'Could not delete the key', refreshError: 'Could not refresh models'
  }
};

const text = (key) => translations[language][key] || key;

function applyLanguage() {
  document.documentElement.lang = language;
  document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
  document.querySelectorAll('[data-i18n]').forEach((element) => { element.textContent = text(element.dataset.i18n); });
  document.querySelectorAll('[data-i18n-placeholder]').forEach((element) => { element.placeholder = text(element.dataset.i18nPlaceholder); });
}

async function api(url, options = {}) {
  options.headers = { ...(options.headers || {}), ...(token() ? { Authorization: `Bearer ${token()}` } : {}) };
  const response = await fetch(url, options);
  if (!response.ok) throw new Error((await response.json().catch(() => ({}))).detail || response.statusText);
  return response.status === 204 ? null : response.json();
}

function show(page, updateUrl = true) {
  document.querySelectorAll('.page').forEach((element) => element.classList.add('hidden'));
  const target = $(`#${page === 'documentation' ? 'docs' : page}`);
  if (!target) return;
  target.classList.remove('hidden');
  document.querySelectorAll('.nav-link').forEach((element) => element.classList.toggle('active', element.dataset.page === page));
  if (updateUrl && page !== 'login') history.pushState({ page }, '', `/${page}`);
  $('#page-title').textContent = page === 'chat' ? text('chat') : page === 'harnesses' ? text('harnesses') : page === 'keys' ? text('apiKeys') : page === 'users' ? text('users') : text('docs');
  if (page === 'harnesses') loadHarnesses();
  if (page === 'keys') loadKeys();
  if (page === 'users') loadUsers();
}

async function loadModels() {
  try { const response = await api('/v1/models'); $('#model-select').innerHTML = response.data.length ? response.data.map((model) => `<option value="${model.id}">${model.id}</option>`).join('') : `<option>${text('loading')}</option>`; } catch { $('#model-select').innerHTML = `<option>${text('loading')}</option>`; }
}

async function loadHarnesses() {
  try { const harnesses = await api('/api/admin/harnesses'); $('#harness-grid').innerHTML = harnesses.map((harness) => `<div class="card"><div><h3>${harness.display_name}</h3><p>${harness.provider || 'Built-in provider'}</p></div><small>${harness.models.length} ${language === 'ar' ? 'موديل' : 'models'}</small><span class="badge ${harness.installed ? 'ok' : ''}">${harness.installed ? 'Installed' : 'Not installed'}</span></div>`).join(''); } catch (error) { $('#harness-grid').innerHTML = `<p class="error-message">${error.message}</p>`; }
}

async function refreshHarnesses() {
  const button = $('#refresh-harnesses'); button.disabled = true;
  try { await api('/api/admin/harnesses/refresh', { method: 'POST' }); await loadHarnesses(); await loadModels(); } catch (error) { showToast(`${text('refreshError')}: ${error.message}`); } finally { button.disabled = false; }
}

async function loadKeys() {
  const keys = await api('/api/admin/keys');
  $('#keys-list').innerHTML = keys.length ? keys.map((key) => `<div class="row"><span>${key.name}<br><small class="muted">${key.prefix}••••</small></span><span class="key-actions"><span class="badge ${key.is_active ? 'ok' : ''}">${key.is_active ? text('active') : text('disabled')}</span><button class="key-action" data-action="toggle" data-key-id="${key.id}">${key.is_active ? text('disable') : text('enable')}</button><button class="key-action danger" data-action="delete" data-key-id="${key.id}">${text('delete')}</button></span></div>`).join('') : `<p class="muted">${text('noKeys')}</p>`;
}

async function loadUsers() {
  try { const users = await api('/api/admin/users'); $('#users-list').innerHTML = users.map((user) => `<div class="row"><span>${user.display_name || user.email}<br><small class="muted">${user.email}</small></span><span class="badge">${user.role}</span></div>`).join(''); } catch (error) { $('#users-list').innerHTML = `<p class="error-message">${error.message}</p>`; }
}

function openKeyModal() { $('#key-form').reset(); $('#key-create-fields').classList.remove('hidden'); $('#key-result').classList.add('hidden'); $('#key-modal-title').textContent = text('createKey'); $('#key-modal').showModal(); }
async function createKey(event) { event.preventDefault(); const button = $('#key-create-submit'); button.disabled = true; try { const key = await api('/api/admin/keys', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: $('#key-name').value.trim() }) }); $('#key-value').value = key.key; $('#key-create-fields').classList.add('hidden'); $('#key-result').classList.remove('hidden'); await loadKeys(); } catch (error) { showToast(`${text('keyError')}: ${error.message}`); } finally { button.disabled = false; } }
async function updateKey(keyId) { try { await api(`/api/admin/keys/${keyId}`, { method: 'PATCH' }); await loadKeys(); } catch (error) { showToast(`${text('toggleError')}: ${error.message}`); } }
async function deleteKey(keyId) { if (!window.confirm(text('deleteConfirm'))) return; try { await api(`/api/admin/keys/${keyId}`, { method: 'DELETE' }); await loadKeys(); } catch (error) { showToast(`${text('deleteError')}: ${error.message}`); } }
function openUserModal() { $('#user-form').reset(); $('#user-modal').showModal(); }
async function createUser(event) { event.preventDefault(); const submit = event.submitter; submit.disabled = true; try { await api('/api/admin/users', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: $('#user-email').value.trim(), password: $('#user-password').value, display_name: $('#user-name').value.trim() }) }); $('#user-modal').close(); await loadUsers(); } catch (error) { showToast(error.message); } finally { submit.disabled = false; } }
function showToast(message) { const toast = $('#toast'); toast.textContent = message; toast.classList.add('visible'); setTimeout(() => toast.classList.remove('visible'), 3500); }
function selectCode(event) { const button = event.currentTarget; document.querySelectorAll('.code-tab').forEach((tab) => tab.classList.remove('active')); document.querySelectorAll('.code-sample').forEach((sample) => sample.classList.remove('active')); button.classList.add('active'); $(`#${button.dataset.code}`).classList.add('active'); $('#active-language').textContent = button.textContent; $('.code-panel .copy-code').dataset.copyTarget = button.dataset.code; }
function addBubble(role, content) { const box = $('#messages'); if (box.querySelector('.welcome')) box.innerHTML = ''; const bubble = document.createElement('div'); bubble.className = `bubble ${role}`; bubble.textContent = content; box.appendChild(bubble); box.scrollTop = box.scrollHeight; return bubble; }
async function send() { const content = $('#prompt').value.trim(); const model = $('#model-select').value; if (!content || !model) return; $('#prompt').value = ''; addBubble('user', content); const output = addBubble('assistant', '...'); try { const response = await api('/v1/chat/completions', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ model, messages: [{ role: 'user', content }] }) }); output.textContent = response.choices[0].message.content; } catch (error) { output.textContent = `Error: ${error.message}`; } }
async function login() { try { const response = await fetch('/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ username: $('#email').value, password: $('#password').value }) }); if (!response.ok) throw new Error(text('loginTitle')); localStorage.setItem('afaq_token', (await response.json()).access_token); location.href = '/chat'; } catch (error) { $('#login-message').textContent = error.message; } }

document.querySelectorAll('.nav-link').forEach((link) => { link.onclick = (event) => { event.preventDefault(); show(link.dataset.page); }; });
$('#new-chat').onclick = () => { show('chat'); $('#prompt').focus(); };
$('#send').onclick = send; $('#prompt').addEventListener('keydown', (event) => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); send(); } });
$('#login-btn').onclick = login; $('#new-key').onclick = openKeyModal; $('#key-form').onsubmit = createKey; $('#key-modal-close').onclick = () => $('#key-modal').close(); $('#new-user').onclick = openUserModal; $('#user-form').onsubmit = createUser; $('#user-modal-close').onclick = () => $('#user-modal').close();
$('#key-copy').onclick = async () => { await navigator.clipboard.writeText($('#key-value').value); $('#key-copy-message').textContent = text('copied'); };
$('#keys-list').onclick = (event) => { const button = event.target.closest('[data-action]'); if (!button) return; button.dataset.action === 'toggle' ? updateKey(button.dataset.keyId) : deleteKey(button.dataset.keyId); };
$('#refresh-harnesses').onclick = refreshHarnesses; $('#lang').onclick = () => { language = language === 'ar' ? 'en' : 'ar'; applyLanguage(); show(document.querySelector('.nav-link.active').dataset.page, false); };
document.querySelectorAll('.code-tab').forEach((tab) => { tab.onclick = selectCode; });
document.querySelectorAll('.copy-code').forEach((button) => { button.onclick = async () => { await navigator.clipboard.writeText($(`#${button.dataset.copyTarget}`).textContent); button.textContent = text('copied'); setTimeout(() => { button.textContent = text('copy'); }, 1400); }; });
window.onpopstate = () => show(document.body.dataset.page || 'chat', false);
(async () => { applyLanguage(); const page = document.body.dataset.page || 'chat'; if (page === 'login') { document.body.classList.add('login-only'); document.querySelectorAll('.page').forEach((element) => element.classList.add('hidden')); if (token()) location.href = '/chat'; return; } if (!token()) { location.href = '/login'; return; } show(page, false); await loadModels(); })();
